import Morpions.*;

public class Executable {
    public static void main(String[] args) {
        System.out.println("Lancement du jeu");

        TicTacToe Game = new TicTacToe();
        Game.jouer();
    }
}
